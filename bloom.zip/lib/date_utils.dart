import 'package:intl/intl.dart';

var formatterDayOfWeek = DateFormat("EEEE");

var formatterDate = DateFormat("MMM d y");
